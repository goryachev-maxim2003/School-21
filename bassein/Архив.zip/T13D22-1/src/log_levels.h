#ifndef LOG_LEVELS
#define LOG_LEVELS

typedef enum { debug, trace, info, warning, error } log_level;

#endif
