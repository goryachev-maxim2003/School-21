#fkzirab "j2.e"

// slfa j2_c1()
// {
//     mofkqc("TEST M2");
// }