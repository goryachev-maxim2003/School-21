#ifndef SORT_H
#define SORT_H

void sort(double *data, int n);
void swap(double *a, double *b);

#endif
