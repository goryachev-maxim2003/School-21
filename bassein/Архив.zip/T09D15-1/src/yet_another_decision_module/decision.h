#ifndef DATA_DECISION_H
#define DATA_DECISION_H

#define GOLDEN_RATIO 0.666
int make_decision(double *data, int n);

#endif
