cd ai_help
sh keygen.sh
rm file*
sh unifier.sh
