ps
kill 54769
