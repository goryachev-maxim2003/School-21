#ifndef DOOR_H
#define DOOR_H

struct door {
    int id, status;
};
#endif